# Secret Launcher

A Compose home-screen launcher for Android (tested target: Redmi / HyperOS / MIUI).

## Features
- Home screen with clock, 4-app dock, swipe-up app drawer with search
- Lists apps from **every profile**: main user, work profile, Dual Apps clones (via `LauncherApps`)
- **Secret space**: tap the clock **5 times within 2 seconds**
  - Long-press any app, then "Hide in secret space". It vanishes from the drawer, dock and search.
  - Long-press inside the secret space to remove an app from it.
  - Space auto-closes on Home press or when you leave the launcher.
- Icons load on background threads with an LRU cache to keep scrolling smooth

## Build
1. Open the `SecretLauncher` folder in Android Studio (Ladybug or newer). It will create the Gradle wrapper and sync.
2. Run on your Redmi phone (enable USB debugging).
3. Press Home and pick **Secret Launcher** > Always.

## Notes
- Same app, two copies: turn on Dual Apps in Settings (or use Shelter/Island), and the clone shows up as a second entry with a badge. You can hide either or both.
- This cannot trigger Xiaomi's real Second Space (a system user switch); the secret space is inside the launcher only.
- Tweak the gesture in `LauncherScreen.kt` (`SECRET_TAPS`, `SECRET_WINDOW_MS`).
