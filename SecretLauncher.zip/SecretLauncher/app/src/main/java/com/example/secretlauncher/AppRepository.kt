package com.example.secretlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(
    val label: String,
    val component: ComponentName,
    val user: UserHandle,
    val userSerial: Long,
    val isClone: Boolean,
) {
    /** Unique per app AND per profile, so a clone is a separate entry from the original. */
    val key: String get() = "${component.flattenToString()}#$userSerial"
}

class AppRepository(private val ctx: Context) {
    private val launcherApps = ctx.getSystemService(LauncherApps::class.java)
    private val userManager = ctx.getSystemService(UserManager::class.java)
    private val iconCache = LruCache<String, ImageBitmap>(400)
    private var callback: LauncherApps.Callback? = null

    /** Lists launchable apps from every profile (main, work profile, Dual Apps clones). */
    fun load(): List<AppEntry> {
        val me = Process.myUserHandle()
        return userManager.userProfiles
            .flatMap { user ->
                val serial = userManager.getSerialNumberForUser(user)
                launcherApps.getActivityList(null, user).map { info ->
                    AppEntry(info.label.toString(), info.componentName, user, serial, user != me)
                }
            }
            .filter { it.component.packageName != ctx.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(app: AppEntry) {
        runCatching { launcherApps.startMainActivity(app.component, app.user, null, null) }
    }

    fun cachedIcon(app: AppEntry): ImageBitmap? = iconCache.get(app.key)

    /** Call from a background dispatcher. Badged icon includes the work/clone badge. */
    fun loadIcon(app: AppEntry): ImageBitmap? {
        iconCache.get(app.key)?.let { return it }
        val info = launcherApps.resolveActivity(Intent().setComponent(app.component), app.user)
            ?: return null
        val bmp = info.getBadgedIcon(0).toBitmap(128, 128).asImageBitmap()
        iconCache.put(app.key, bmp)
        return bmp
    }

    fun register(onChange: () -> Unit) {
        val cb = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String, user: UserHandle) = onChange()
            override fun onPackageAdded(packageName: String, user: UserHandle) = onChange()
            override fun onPackageChanged(packageName: String, user: UserHandle) = onChange()
            override fun onPackagesAvailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = onChange()
            override fun onPackagesUnavailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = onChange()
        }
        callback = cb
        launcherApps.registerCallback(cb)
    }

    fun unregister() {
        callback?.let { launcherApps.unregisterCallback(it) }
        callback = null
    }
}
