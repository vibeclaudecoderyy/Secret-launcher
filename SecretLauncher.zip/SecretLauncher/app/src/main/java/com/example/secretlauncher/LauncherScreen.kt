package com.example.secretlauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType as HF
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// Secret gesture: tap the clock this many times within this window.
private const val SECRET_TAPS = 5
private const val SECRET_WINDOW_MS = 2000L

@Composable
fun LauncherScreen(vm: LauncherViewModel) {
    val apps by vm.apps.collectAsState()
    val hidden by vm.hidden.collectAsState()
    val visibleApps = remember(apps, hidden) { apps.filter { it.key !in hidden } }
    val secretApps = remember(apps, hidden) { apps.filter { it.key in hidden } }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize()) {
            HomePage(vm, visibleApps)

            AnimatedVisibility(
                visible = vm.drawerOpen,
                enter = slideInVertically { it / 3 } + fadeIn(),
                exit = slideOutVertically { it / 3 } + fadeOut(),
            ) {
                DrawerPage(vm, visibleApps)
            }

            AnimatedVisibility(visible = vm.secretOpen, enter = fadeIn(), exit = fadeOut()) {
                SecretPage(vm, secretApps)
            }
        }
    }
}

@Composable
private fun HomePage(vm: LauncherViewModel, apps: List<AppEntry>) {
    val haptic = LocalHapticFeedback.current
    val taps = remember { mutableListOf<Long>() }
    val time by produceState(LocalDateTime.now()) {
        while (true) { value = LocalDateTime.now(); delay(10_000) }
    }
    val dock = remember(apps) { apps.take(4) }

    Box(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -120f) vm.drawerOpen = true },
                ) { _, dy -> total += dy }
            }
    ) {
        Column(
            Modifier.align(Alignment.TopCenter).padding(top = 72.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // The clock is the secret trigger. It looks and behaves like a normal clock.
            Text(
                time.format(DateTimeFormatter.ofPattern("HH:mm")),
                fontSize = 64.sp,
                color = Color.White,
                modifier = Modifier.pointerInput(Unit) {
                    detectTapGestures {
                        val now = System.currentTimeMillis()
                        taps.add(now)
                        taps.removeAll { now - it > SECRET_WINDOW_MS }
                        if (taps.size >= SECRET_TAPS) {
                            taps.clear()
                            haptic.performHapticFeedback(HF.LongPress)
                            vm.secretOpen = true
                        }
                    }
                },
            )
            Text(
                time.format(DateTimeFormatter.ofPattern("EEE, d MMM")),
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 16.sp,
            )
        }

        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            dock.forEach { app ->
                AppCell(app, vm, showLabel = false, menuLabel = "Hide in secret space") { vm.hide(app) }
            }
        }
    }
}

@Composable
private fun DrawerPage(vm: LauncherViewModel, apps: List<AppEntry>) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }
    BackHandler { vm.drawerOpen = false }

    Column(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.72f)).systemBarsPadding()
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search apps") },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp),
        )
        AppGrid(filtered, vm, menuLabel = "Hide in secret space") { vm.hide(it) }
    }
}

@Composable
private fun SecretPage(vm: LauncherViewModel, apps: List<AppEntry>) {
    BackHandler { vm.secretOpen = false }
    Column(
        Modifier.fillMaxSize().background(Color(0xFF0B0B12)).systemBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Secret space", fontSize = 22.sp, color = Color.White, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.secretOpen = false }) { Text("Close") }
        }
        if (apps.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Empty. Long-press any app in the drawer\nand choose \"Hide in secret space\".",
                    color = Color.White.copy(alpha = 0.6f),
                )
            }
        } else {
            AppGrid(apps, vm, menuLabel = "Remove from secret space") { vm.unhide(it) }
        }
    }
}

@Composable
private fun AppGrid(
    apps: List<AppEntry>,
    vm: LauncherViewModel,
    menuLabel: String,
    onMenu: (AppEntry) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(apps, key = { it.key }) { app ->
            AppCell(app, vm, showLabel = true, menuLabel = menuLabel) { onMenu(app) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppCell(
    app: AppEntry,
    vm: LauncherViewModel,
    showLabel: Boolean,
    menuLabel: String,
    onMenu: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    // Icons load off the main thread and are cached, so scrolling stays smooth.
    val icon by produceState(vm.repo.cachedIcon(app), app.key) {
        if (value == null) value = withContext(Dispatchers.IO) { vm.repo.loadIcon(app) }
    }

    Column(
        Modifier
            .padding(vertical = 10.dp)
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = { vm.repo.launch(app) },
                onLongClick = { menu = true },
            )
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(56.dp)) {
            icon?.let { Image(it, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
        }
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            Text(
                app.label,
                color = Color.White,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 72.dp),
            )
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(menuLabel) },
                onClick = { menu = false; onMenu() },
            )
        }
    }
}
