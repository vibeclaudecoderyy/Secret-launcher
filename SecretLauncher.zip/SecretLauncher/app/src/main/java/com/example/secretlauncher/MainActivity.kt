package com.example.secretlauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LauncherScreen(vm) }
    }

    /** Home button pressed while we're already on top: close drawer and hide the secret space. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.closeAll()
    }

    /** Secret space never survives leaving the launcher. */
    override fun onStop() {
        super.onStop()
        vm.secretOpen = false
    }
}
