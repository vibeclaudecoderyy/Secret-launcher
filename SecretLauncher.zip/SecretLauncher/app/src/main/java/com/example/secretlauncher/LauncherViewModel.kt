package com.example.secretlauncher

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    val repo = AppRepository(app)
    private val prefs = app.getSharedPreferences("secret_space", 0)

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()

    private val _hidden = MutableStateFlow(prefs.getStringSet("hidden", emptySet()).orEmpty())
    val hidden: StateFlow<Set<String>> = _hidden.asStateFlow()

    var drawerOpen by mutableStateOf(false)
    var secretOpen by mutableStateOf(false)

    init {
        refresh()
        repo.register { refresh() }
    }

    fun refresh() {
        viewModelScope.launch(Dispatchers.Default) { _apps.value = repo.load() }
    }

    fun hide(app: AppEntry) = saveHidden(_hidden.value + app.key)
    fun unhide(app: AppEntry) = saveHidden(_hidden.value - app.key)

    private fun saveHidden(set: Set<String>) {
        _hidden.value = set
        prefs.edit().putStringSet("hidden", set).apply()
    }

    fun closeAll() {
        secretOpen = false
        drawerOpen = false
    }

    override fun onCleared() = repo.unregister()
}
